﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace WpfApplication5.Core
{
    public static class CoreNavigate
    {
        public static Frame MyCore { get; set; }
    }
}
